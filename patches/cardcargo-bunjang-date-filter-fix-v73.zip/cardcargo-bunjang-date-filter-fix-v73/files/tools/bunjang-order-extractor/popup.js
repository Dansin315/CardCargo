const smartButton = document.getElementById('smart')
const fullButton = document.getElementById('full')
const pauseButton = document.getElementById('pause')
const stopButton = document.getElementById('stop')
const resetButton = document.getElementById('reset')
const exportPartialButton = document.getElementById('exportPartial')
const dateFromInput = document.getElementById('dateFrom')
const dateToInput = document.getElementById('dateTo')
const last7Button = document.getElementById('last7')
const status = document.getElementById('status')
const summary = document.getElementById('summary')

const SYNC_KEY = 'cardcargoBunjangSmartSyncV1'
const CAPTURE_KEY = 'cardcargoBunjangNetworkCaptureV70'
const PARTIAL_EXPORT_KEY = 'cardcargoBunjangPartialExportV70'
const MAX_SCROLL_ROUNDS = 80
const DETAIL_RENDER_TIMEOUT = 12000
const DATE_FILTER_KEY = 'cardcargoBunjangDateFilterV72'

let running = false
let paused = false
let stopRequested = false

let currentRun = {
  mode: null,
  tab: null,
  discovered: [],
  targets: [],
  skipped: 0,
  orders: [],
  outsideRange: 0,
  checkedDetails: 0,
}

let lastExportPayload = null
let currentDateRange = {
  from: null,
  to: null,
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}



function localIsoDate(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function defaultLast7Days() {
  const today = new Date()
  const from = new Date(
    today.getFullYear(),
    today.getMonth(),
    today.getDate() - 6,
  )

  return {
    from: localIsoDate(from),
    to: localIsoDate(today),
  }
}

function normalizeDateValue(value) {
  const text = String(value || '').trim()
  return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : null
}

function compareIsoDates(left, right) {
  return String(left).localeCompare(String(right))
}

function inDateRange(date, range = currentDateRange) {
  if (!date) return false

  const normalized = normalizeDateValue(date)
  if (!normalized) return false

  if (range.from && compareIsoDates(normalized, range.from) < 0) {
    return false
  }

  if (range.to && compareIsoDates(normalized, range.to) > 0) {
    return false
  }

  return true
}

function validateDateRange() {
  const from = normalizeDateValue(dateFromInput.value)
  const to = normalizeDateValue(dateToInput.value)

  if (!from || !to) {
    throw new Error('Bitte ein gültiges Von- und Bis-Datum auswählen.')
  }

  if (compareIsoDates(from, to) > 0) {
    throw new Error('Das Von-Datum darf nicht nach dem Bis-Datum liegen.')
  }

  return { from, to }
}

async function saveDateRange(range) {
  currentDateRange = range

  await chrome.storage.local.set({
    [DATE_FILTER_KEY]: range,
  })
}

async function initializeDateRange() {
  const stored = await chrome.storage.local.get(DATE_FILTER_KEY)
  const saved = stored?.[DATE_FILTER_KEY]

  const range =
    saved &&
    normalizeDateValue(saved.from) &&
    normalizeDateValue(saved.to)
      ? {
          from: saved.from,
          to: saved.to,
        }
      : defaultLast7Days()

  dateFromInput.value = range.from
  dateToInput.value = range.to
  currentDateRange = range
}

async function visibleOverviewDates(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const text = String(
        document.body?.innerText || document.body?.textContent || '',
      )

      const found = new Set()

      for (const match of text.matchAll(
        /(\d{2,4})년\s*(\d{1,2})월\s*(\d{1,2})일/g,
      )) {
        let year = match[1]
        if (year.length === 2) year = `20${year}`

        found.add(
          `${year}-${String(match[2]).padStart(2, '0')}-${String(match[3]).padStart(2, '0')}`,
        )
      }

      return [...found]
    },
  })

  return Array.isArray(result) ? result : []
}

function summarizeOrders(orders) {
  const trackingCount = orders.filter(
    (order) => order?.extracted?.domesticTrackingNumber,
  ).length
  const priceCount = orders.filter(
    (order) => order?.extracted?.productAmount !== null,
  ).length
  const dateCount = orders.filter(
    (order) => Boolean(order?.extracted?.purchasedAt),
  ).length
  const shippingCount = orders.filter(
    (order) => order?.extracted?.domesticShippingAmount !== null,
  ).length
  const sellerCount = orders.filter(
    (order) => Boolean(order?.extracted?.sellerName),
  ).length
  const errors = orders.filter(
    (order) => Boolean(order?.warning),
  ).length

  return {
    trackingCount,
    priceCount,
    dateCount,
    shippingCount,
    sellerCount,
    errors,
  }
}

function makeExportPayload(reason) {
  if (!currentRun.orders.length || !currentRun.tab) return null

  return {
    source: 'cardcargo-bunjang-order-extractor',
    version: 4.2,
    mode: currentRun.mode,
    partialExport: reason !== 'complete',
    exportReason: reason,
    stoppedEarly: reason === 'stop',
    pausedAtExport: reason === 'pause',
    capturedAt: new Date().toISOString(),
    pageUrl: currentRun.tab.url,
    dateRange: {
      from: currentDateRange.from,
      to: currentDateRange.to,
    },
    discovery: {
      ordersFound: currentRun.discovered.length,
      requested: currentRun.targets.length,
      skippedComplete: currentRun.skipped,
      exportedSoFar: currentRun.orders.length,
    },
    orders: currentRun.orders,
  }
}

async function exportCurrentProgress(reason) {
  let payload = await persistPartialProgress(reason)

  if (!payload) {
    const stored = await chrome.storage.local.get(PARTIAL_EXPORT_KEY)
    const previous = stored?.[PARTIAL_EXPORT_KEY]
    if (previous && Array.isArray(previous.orders) && previous.orders.length) {
      payload = {
        ...previous,
        partialExport: true,
        exportReason: reason,
        stoppedEarly: reason === 'stop',
        pausedAtExport: reason === 'pause',
        capturedAt: new Date().toISOString(),
      }
    }
  }

  if (!payload) return { copied: false, count: 0 }

  await navigator.clipboard.writeText(JSON.stringify(payload, null, 2))
  lastExportPayload = payload
  exportPartialButton.disabled = false

  const stats = summarizeOrders(payload.orders)
  renderSummary([
    ['Exportierte Bestellungen', payload.orders.length],
    ['Warenwert erkannt', stats.priceCount],
    ['Kaufdatum erkannt', stats.dateCount],
    ['Versandkosten erkannt', stats.shippingCount],
    ['Verkäufer erkannt', stats.sellerCount],
    ['Tracking erkannt', stats.trackingCount],
    ['Fehler', stats.errors],
  ])

  return { copied: true, count: payload.orders.length }
}

function setRunState(next) {
  running = next
  smartButton.disabled = next
  fullButton.disabled = next
  resetButton.disabled = next
  exportPartialButton.disabled = next || !lastExportPayload
  pauseButton.disabled = !next
  stopButton.disabled = !next

  if (!next) {
    paused = false
    stopRequested = false
    pauseButton.textContent = 'Pausieren'
  }
}

function renderSummary(rows) {
  summary.replaceChildren()

  for (const [label, value] of rows) {
    const left = document.createElement('span')
    left.textContent = label
    const right = document.createElement('strong')
    right.textContent = String(value)
    summary.append(left, right)
  }

  summary.hidden = rows.length === 0
}

async function waitWhilePaused(phase) {
  while (paused && !stopRequested) {
    status.textContent =
      `Pausiert.\n${phase}\nMit „Fortsetzen“ geht es an derselben Stelle weiter.`
    await sleep(150)
  }
  return !stopRequested
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true,
  })

  if (!tab?.id || !tab.url) {
    throw new Error('Kein aktiver Tab gefunden.')
  }

  if (new URL(tab.url).hostname !== 'order.bunjang.co.kr') {
    throw new Error('Bitte die Bunjang-Kaufübersicht öffnen.')
  }

  return tab
}

async function waitForTabComplete(tabId, timeout = 15000) {
  const started = Date.now()

  while (Date.now() - started < timeout) {
    if (stopRequested) return
    const tab = await chrome.tabs.get(tabId)
    if (tab.status === 'complete') return
    await sleep(120)
  }
}

async function ensureCaptureBridge(tab) {
  try {
    const result = await chrome.tabs.sendMessage(tab.id, {
      type: 'cardcargo-bunjang-capture-ping',
    })
    if (result?.ok) return
  } catch {
    // Reload below.
  }

  status.textContent =
    'Aktiviere den Netzwerk-Extractor …\nDie Bunjang-Seite wird einmal neu geladen.'

  await chrome.tabs.reload(tab.id)
  await waitForTabComplete(tab.id)
  await sleep(1000)
}

async function readSyncState() {
  const stored = await chrome.storage.local.get(SYNC_KEY)
  const value = stored?.[SYNC_KEY]

  return {
    orders:
      value?.orders && typeof value.orders === 'object'
        ? value.orders
        : {},
  }
}

async function writeSyncState(state) {
  await chrome.storage.local.set({ [SYNC_KEY]: state })
}

async function capturedOrders() {
  const [captureStored, syncStored] = await Promise.all([
    chrome.storage.local.get(CAPTURE_KEY),
    chrome.storage.local.get(SYNC_KEY),
  ])

  const value = captureStored?.[CAPTURE_KEY]
  const sync = syncStored?.[SYNC_KEY]
  const map = value?.orders && typeof value.orders === 'object' ? value.orders : {}
  const syncOrders = sync?.orders && typeof sync.orders === 'object' ? sync.orders : {}

  return Object.values(map)
    .filter((candidate) => {
      const id = String(candidate?.orderId || '')
      if (!/^\d{6,12}$/.test(id)) return false
      if (syncOrders[id]?.invalidCandidate === true) return false
      return Number(candidate?.confidence || 0) >= 80
    })
    .sort((a, b) => Number(b?.confidence || 0) - Number(a?.confidence || 0))
    .map((candidate) => ({
      orderId: String(candidate.orderId),
      orderUrl: `https://order.bunjang.co.kr/purchases/${candidate.orderId}`,
      confidence: Number(candidate.confidence || 0),
      evidence: candidate.evidence || null,
    }))
}

async function directDomOrders(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const found = new Set()
      const html = document.documentElement?.innerHTML || ''

      for (const match of html.matchAll(/\/purchases\/(\d{6,12})/g)) {
        if (match?.[1]) found.add(match[1])
      }

      return [...found]
    },
  })

  return (Array.isArray(result) ? result : []).map((orderId) => ({
    orderId,
    orderUrl: `https://order.bunjang.co.kr/purchases/${orderId}`,
    confidence: 100,
    evidence: 'dom-purchases-route',
  }))
}

async function scrollOneStep(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: async () => {
      const labels = ['더보기', '더 보기', '더 불러오기', 'more', 'load more']

      for (const button of document.querySelectorAll(
        'button, [role="button"]',
      )) {
        const text = String(
          button.innerText || button.textContent || '',
        )
          .trim()
          .toLowerCase()

        if (
          text &&
          labels.some((label) => text.includes(label.toLowerCase()))
        ) {
          const rect = button.getBoundingClientRect()
          if (rect.width > 0 && rect.height > 0) {
            try {
              button.click()
            } catch {
              // Ignore.
            }
          }
        }
      }

      window.scrollTo({
        top: document.documentElement.scrollHeight,
        behavior: 'auto',
      })

      await new Promise((resolve) => setTimeout(resolve, 700))

      return {
        height: document.documentElement.scrollHeight,
        y: window.scrollY,
      }
    },
  })

  return result || {}
}

async function discoverOrders(tabId, range) {
  const byId = new Map()
  let stableRounds = 0
  let previousSignal = ''
  let boundaryStableRounds = 0
  let previousBoundarySignal = ''

  async function mergeCurrentCandidates() {
    const [network, dom] = await Promise.all([
      capturedOrders(),
      directDomOrders(tabId),
    ])

    for (const order of [...network, ...dom]) {
      byId.set(order.orderId, order)
    }
  }

  for (let round = 0; round < MAX_SCROLL_ROUNDS; round += 1) {
    if (stopRequested) break
    if (!(await waitWhilePaused(`Discovery: ${byId.size} Orders erkannt.`))) {
      break
    }

    await mergeCurrentCandidates()

    status.textContent =
      `Lese Bunjang-Netzwerkdaten …\n` +
      `${byId.size} Bestellnummern erkannt · Scroll-Runde ${round + 1}`

    const step = await scrollOneStep(tabId)

    // Network responses and the extension bridge are asynchronous. v72 only
    // waited 250 ms and could therefore hit the date boundary before all
    // orders from the just-loaded block had reached chrome.storage.
    await sleep(350)
    await mergeCurrentCandidates()

    const signal = `${byId.size}:${step.height || 0}`
    let crossedLowerBoundary = false

    try {
      const visibleDates = await visibleOverviewDates(tabId)

      if (visibleDates.length) {
        const oldestVisible = [...visibleDates].sort()[0]

        crossedLowerBoundary = Boolean(
          range.from &&
          compareIsoDates(oldestVisible, range.from) < 0,
        )
      }
    } catch {
      // Optimization only; rendered detail date remains final authority.
    }

    if (crossedLowerBoundary) {
      // Do NOT stop immediately. A Bunjang scroll can append a block that
      // contains both in-range dates (e.g. Aug 21/22) and the first older date
      // (e.g. Aug 19). Wait for all delayed network responses from that block.
      status.textContent =
        `Zeitraumgrenze erreicht. Warte noch auf alle Bestellungen des geladenen Blocks …\n` +
        `${byId.size} Bestellnummern bisher erkannt.`

      await sleep(1000)
      await mergeCurrentCandidates()

      const boundarySignal = `${byId.size}:${step.height || 0}`

      if (boundarySignal === previousBoundarySignal) {
        boundaryStableRounds += 1
      } else {
        boundaryStableRounds = 1
      }

      previousBoundarySignal = boundarySignal

      // Two stable boundary passes are required. This is deliberately more
      // conservative than v72 so no same-page in-range purchases are lost.
      if (boundaryStableRounds >= 2) {
        status.textContent =
          `Zeitraum vollständig erfasst. ${byId.size} Bestellnummern wurden vor dem Detailfilter erkannt.`
        break
      }
    } else {
      boundaryStableRounds = 0
      previousBoundarySignal = ''
    }

    if (signal === previousSignal) {
      stableRounds += 1
    } else {
      stableRounds = 0
    }
    previousSignal = signal

    if (stableRounds >= 4) break
  }

  // Final settle pass before returning, even if scrolling stopped for another
  // reason. This catches the last delayed response batch.
  await sleep(700)
  await mergeCurrentCandidates()

  return [...byId.values()]
}

async function waitForRenderedOrder(tabId, orderId) {
  const started = Date.now()

  while (Date.now() - started < DETAIL_RENDER_TIMEOUT) {
    if (stopRequested) return { status: 'stopped' }
    if (!(await waitWhilePaused(`Warte auf gerenderte Bestellung #${orderId} …`))) {
      return { status: 'stopped' }
    }

    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId },
        func: (expectedOrderId) => {
          const text = String(
            document.body?.innerText || document.body?.textContent || '',
          )
            .replace(/\u00a0/g, ' ')
            .trim()

          const invalid =
            text.includes('주문정보를 조회 할 수 없습니다') ||
            text.includes('주문정보를 조회할 수 없습니다') ||
            text.includes('주문 정보를 조회 할 수 없습니다') ||
            text.includes('주문 정보를 조회할 수 없습니다')

          if (invalid) return { status: 'invalid', sample: text.slice(0, 1000) }

          const valid =
            text.includes(`주문번호 ${expectedOrderId}`) ||
            (
              text.includes('주문번호') &&
              text.includes('판매자') &&
              (text.includes('결제정보') || text.includes('거래정보') || text.includes('운송장'))
            )

          return { status: valid ? 'valid' : 'waiting' }
        },
        args: [orderId],
      })

      if (result?.status === 'valid' || result?.status === 'invalid') return result
    } catch {
      // Tab may still be navigating/rendering.
    }

    await sleep(180)
  }

  return { status: 'timeout' }
}

async function extractRenderedDetail(tabId, order) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (expectedOrderId, orderUrl) => {
      function lines(value) {
        return String(value || '')
          .replace(/\u00a0/g, ' ')
          .split(/\r?\n/)
          .map((line) => line.replace(/[ \t]+/g, ' ').trim())
          .filter(Boolean)
      }

      function afterLabel(all, label) {
        const index = all.findIndex(
          (line) =>
            line === label ||
            line.startsWith(`${label} `) ||
            line.startsWith(`${label}:`) ||
            line.startsWith(`${label}：`),
        )

        if (index < 0) return null

        const inline = all[index]
          .slice(label.length)
          .trim()
          .replace(/^[:：]\s*/, '')

        return inline || all[index + 1] || null
      }

      function won(value) {
        if (!value) return null
        const parsed = Number(String(value).replace(/[^\d]/g, ''))
        return Number.isFinite(parsed) ? parsed : null
      }

      function tracking(all) {
        const index = all.findIndex((line) => line.startsWith('운송장'))
        if (index < 0) return { carrier: null, trackingNumber: null }

        const inline = all[index]
          .slice('운송장'.length)
          .trim()
          .replace(/^[:：]\s*/, '')

        if (inline) {
          const match = inline.match(/^(.+?)\s+([A-Z0-9 -]{8,32})$/i)
          if (match?.[2]) {
            return {
              carrier: match[1].trim(),
              trackingNumber: match[2].replace(/[\s-]/g, ''),
            }
          }
        }

        const carrier = inline || all[index + 1] || null

        for (let offset = inline ? 1 : 2; offset <= 4; offset += 1) {
          const candidate = all[index + offset]
          if (!candidate) continue

          const compact = candidate.replace(/[\s-]/g, '')
          if (/^[A-Z0-9]{8,32}$/i.test(compact) && /\d{6,}/.test(compact)) {
            return {
              carrier:
                offset > 1
                  ? all[index + offset - 1] || carrier
                  : carrier,
              trackingNumber: compact,
            }
          }
        }

        return { carrier, trackingNumber: null }
      }

      function orderDateTime(text) {
        const normalized = text.replace(/\s+/g, ' ')
        const match = normalized.match(
          new RegExp(
            `주문번호\\s*${expectedOrderId}\\s*(\\d{2,4})년\\s*(\\d{1,2})월\\s*(\\d{1,2})일\\s*(\\d{1,2}):(\\d{2})`,
          ),
        )

        if (!match) return { purchasedAt: null, orderedAt: null }

        const year = match[1].length === 2 ? `20${match[1]}` : match[1]
        const month = match[2].padStart(2, '0')
        const day = match[3].padStart(2, '0')
        const hour = match[4].padStart(2, '0')
        const minute = match[5].padStart(2, '0')

        return {
          purchasedAt: `${year}-${month}-${day}`,
          orderedAt: `${year}-${month}-${day}T${hour}:${minute}:00+09:00`,
        }
      }

      function amountAfter(all, label) {
        return won(afterLabel(all, label))
      }

      function titleFrom(all) {
        const orderIndex = all.findIndex((line) =>
          line.includes(`주문번호 ${expectedOrderId}`),
        )

        const window = all.slice(
          orderIndex >= 0 ? orderIndex + 1 : 0,
          (orderIndex >= 0 ? orderIndex + 1 : 0) + 16,
        )

        const priceIndex = window.findIndex((line) =>
          /^[+]?[\d,.]+\s*원$/.test(line),
        )

        if (priceIndex <= 0) return null

        const statuses = new Set([
          '거래 완료',
          '배송 완료',
          '배송 중',
          '거래 취소 완료',
          '취소 요청 보냄',
          '결제 완료',
          '배송 준비',
        ])

        for (let i = priceIndex - 1; i >= 0; i -= 1) {
          const candidate = window[i]
          if (
            !statuses.has(candidate) &&
            !/배송 조회|결제정보|주문 상세/.test(candidate) &&
            !/^주문번호\s/.test(candidate)
          ) {
            return candidate
          }
        }

        return null
      }

      const rawText = String(
        document.body?.innerText || document.body?.textContent || '',
      )
        .replace(/\u00a0/g, ' ')
        .trim()

      const all = lines(rawText)
      const dates = orderDateTime(rawText)
      const shipment = tracking(all)

      const productUrls = [...document.querySelectorAll('a[href]')]
        .map((anchor) => anchor.href)
        .filter((href) => /\/products?\/\d+/i.test(href))
        .slice(0, 12)

      const imageUrls = [...document.querySelectorAll('img')]
        .map((img) => img.currentSrc || img.src || '')
        .filter((src) => /^https?:\/\//i.test(src))
        .slice(0, 12)

      return {
        orderId: expectedOrderId,
        orderUrl,
        text: rawText,
        productUrls,
        imageUrls,
        warning: rawText.includes('주문번호')
          ? null
          : 'Gerenderte Detailseite enthielt keine erwarteten Bestelldaten.',
        extracted: {
          title: titleFrom(all),
          sellerName: afterLabel(all, '판매자'),
          purchasedAt: dates.purchasedAt,
          orderedAt: dates.orderedAt,
          productAmount: amountAfter(all, '상품금액'),
          domesticShippingAmount: amountAfter(all, '배송비'),
          totalAmount: amountAfter(all, '총 결제금액'),
          transactionMethod: afterLabel(all, '거래방법'),
          domesticCarrier: shipment.carrier,
          domesticTrackingNumber: shipment.trackingNumber,
        },
      }
    },
    args: [order.orderId, order.orderUrl],
  })

  return result
}


function exportableOrders(orders) {
  return (orders || []).filter(
    (order) =>
      order &&
      order.invalidCandidate !== true &&
      inDateRange(order?.extracted?.purchasedAt) &&
      typeof order.text === 'string' &&
      order.text.includes('주문번호') &&
      (
        order.extracted?.productAmount !== null ||
        order.extracted?.purchasedAt ||
        order.extracted?.sellerName ||
        order.extracted?.domesticTrackingNumber
      ),
  )
}

async function persistPartialProgress(reason = 'checkpoint') {
  const orders = exportableOrders(currentRun.orders)
  if (!orders.length || !currentRun.tab) return null

  const payload = {
    source: 'cardcargo-bunjang-order-extractor',
    version: 4.3,
    mode: currentRun.mode,
    partialExport: reason !== 'complete',
    exportReason: reason,
    stoppedEarly: reason === 'stop',
    pausedAtExport: reason === 'pause',
    capturedAt: new Date().toISOString(),
    pageUrl: currentRun.tab.url,
    dateRange: {
      from: currentDateRange.from,
      to: currentDateRange.to,
    },
    discovery: {
      ordersFound: currentRun.discovered.length,
      requested: currentRun.targets.length,
      skippedComplete: currentRun.skipped,
      exportedSoFar: orders.length,
      checkedDetails: currentRun.checkedDetails,
      outsideRange: currentRun.outsideRange,
    },
    orders,
  }

  await chrome.storage.local.set({ [PARTIAL_EXPORT_KEY]: payload })
  lastExportPayload = payload
  exportPartialButton.disabled = false
  return payload
}

async function restorePersistentExport() {
  const stored = await chrome.storage.local.get(PARTIAL_EXPORT_KEY)
  const payload = stored?.[PARTIAL_EXPORT_KEY]

  if (payload && Array.isArray(payload.orders) && payload.orders.length) {
    lastExportPayload = payload
    exportPartialButton.disabled = false
    return payload
  }
  return null
}

async function loadRenderedDetails(targets, syncState) {
  const results = []

  if (!targets.length) return results

  const worker = await chrome.tabs.create({
    url: targets[0].orderUrl,
    active: false,
  })

  if (!worker.id) {
    throw new Error('Hilfs-Tab für Bestelldetails konnte nicht erstellt werden.')
  }

  try {
    for (let index = 0; index < targets.length; index += 1) {
      if (stopRequested) break
      if (
        !(await waitWhilePaused(
          `Bestelldetails: ${index}/${targets.length} geladen.`,
        ))
      ) {
        break
      }

      const order = targets[index]

      status.textContent =
        `Lade gerenderte Bestelldetailseite …\n` +
        `${index + 1}/${targets.length} · Order #${order.orderId}`

      if (index > 0) {
        await chrome.tabs.update(worker.id, {
          url: order.orderUrl,
          active: false,
        })
      }

      await waitForTabComplete(worker.id)
      const rendered = await waitForRenderedOrder(worker.id, order.orderId)

      if (rendered.status === 'stopped') break

      if (rendered.status === 'invalid') {
        syncState.orders[order.orderId] = {
          trackingFound: false,
          invalidCandidate: true,
          lastCheckedAt: new Date().toISOString(),
          lastWarning: 'Netzwerk-Kandidat ist keine gültige Bunjang-Bestelldetailseite.',
        }
        await writeSyncState(syncState)
        status.textContent =
          `Ungültigen Netzwerk-Kandidaten #${order.orderId} übersprungen.\n` +
          'Suche mit der nächsten Bestellnummer weiter …'
        continue
      }

      let detail

      if (rendered.status !== 'valid') {
        detail = {
          orderId: order.orderId,
          orderUrl: order.orderUrl,
          text: '',
          productUrls: [],
          imageUrls: [],
          warning: 'Bestelldetailseite wurde nicht rechtzeitig vollständig gerendert.',
          invalidCandidate: false,
          extracted: {
            title: null,
            sellerName: null,
            purchasedAt: null,
            orderedAt: null,
            productAmount: null,
            domesticShippingAmount: null,
            totalAmount: null,
            transactionMethod: null,
            domesticCarrier: null,
            domesticTrackingNumber: null,
          },
        }
      } else {
        detail = await extractRenderedDetail(worker.id, order)
      }

      const purchasedAt = detail?.extracted?.purchasedAt

      if (rendered.status === 'valid') {
        currentRun.checkedDetails += 1
      }

      if (
        rendered.status === 'valid' &&
        purchasedAt &&
        !inDateRange(purchasedAt)
      ) {
        currentRun.outsideRange += 1
        syncState.orders[order.orderId] = {
          trackingFound: Boolean(
            detail?.extracted?.domesticTrackingNumber,
          ),
          invalidCandidate: false,
          lastCheckedAt: new Date().toISOString(),
          lastWarning:
            `Außerhalb des ausgewählten Zeitraums (${currentDateRange.from} bis ${currentDateRange.to}).`,
        }

        await writeSyncState(syncState)

        status.textContent =
          `Order #${order.orderId} liegt am ${purchasedAt} außerhalb des gewählten Zeitraums und wird nicht exportiert.`

        continue
      }

      results.push(detail)
      currentRun.orders = [...results]

      syncState.orders[order.orderId] = {
        trackingFound: Boolean(detail?.extracted?.domesticTrackingNumber),
        invalidCandidate: false,
        lastCheckedAt: new Date().toISOString(),
        lastWarning: detail?.warning || null,
      }

      await Promise.all([
        writeSyncState(syncState),
        persistPartialProgress('checkpoint'),
      ])
    }
  } finally {
    try {
      await chrome.tabs.remove(worker.id)
    } catch {
      // Ignore.
    }
  }

  return results
}

async function run(mode) {
  setRunState(true)
  summary.hidden = true

  try {
    const range = validateDateRange()
    await saveDateRange(range)

    const tab = await activeTab()

    currentRun = {
      mode,
      tab,
      discovered: [],
      targets: [],
      skipped: 0,
      orders: [],
      outsideRange: 0,
      checkedDetails: 0,
    }

    lastExportPayload = null
    exportPartialButton.disabled = true

    await ensureCaptureBridge(tab)

    const syncState = await readSyncState()

    status.textContent =
      `Ermittle Bunjang-Bestellungen im Zeitraum ${range.from} bis ${range.to} …`

    const discovered = await discoverOrders(tab.id, range)
    currentRun.discovered = discovered

    if (!discovered.length) {
      throw new Error(
        'Keine Bestellnummern in den Bunjang-Netzwerkdaten erkannt.',
      )
    }

    const validDiscovered = discovered.filter(
      (order) => syncState.orders[order.orderId]?.invalidCandidate !== true,
    )

    const targets =
      mode === 'full'
        ? validDiscovered
        : validDiscovered.filter((order) => {
            const known = syncState.orders[order.orderId]
            return (
              !known ||
              (known.trackingFound !== true && known.invalidCandidate !== true)
            )
          })

    const skipped = discovered.length - targets.length
    currentRun.targets = targets
    currentRun.skipped = skipped

    renderSummary([
      ['Bestellnummern erkannt', discovered.length],
      ['Detailseiten zu laden', targets.length],
      ['Bereits mit Tracking', skipped],
    ])

    if (stopRequested) return

    if (!targets.length) {
      status.textContent =
        'Smart Sync abgeschlossen: Alle erkannten Bestellungen besitzen bereits Trackingdaten.'
      return
    }

    const orders = await loadRenderedDetails(targets, syncState)

    currentRun.orders = [...orders]

    if (orders.length) {
      await exportCurrentProgress(
        stopRequested ? 'stop' : 'complete',
      )
    }

    const stats = summarizeOrders(orders)

    renderSummary([
      ['Detailseiten geprüft', currentRun.checkedDetails],
      ['Außerhalb Zeitraum', currentRun.outsideRange],
      ['Bestellungen im Zeitraum', orders.length],
      ['Warenwert erkannt', stats.priceCount],
      ['Kaufdatum erkannt', stats.dateCount],
      ['Versandkosten erkannt', stats.shippingCount],
      ['Verkäufer erkannt', stats.sellerCount],
      ['Tracking erkannt', stats.trackingCount],
      ['Fehler', stats.errors],
    ])

    status.textContent = stopRequested
      ? orders.length
        ? `${orders.length} bereits geladene Bestellung(en) wurden als Teil-Batch kopiert.`
        : 'Sync beendet.'
      : 'Detail-Batch vorbereitet. In CardCargo einmal „Aus Zwischenablage einlesen“ verwenden.'
  } catch (error) {
    status.textContent =
      error instanceof Error
        ? error.message
        : 'Bunjang Detail Sync fehlgeschlagen.'
  } finally {
    setRunState(false)
  }
}

smartButton.addEventListener('click', () => void run('smart'))
fullButton.addEventListener('click', () => void run('full'))

pauseButton.addEventListener('click', async () => {
  if (!running) return

  if (paused) {
    paused = false
    pauseButton.textContent = 'Pausieren'
    status.textContent = 'Sync wird fortgesetzt …'
    return
  }

  paused = true
  pauseButton.textContent = 'Fortsetzen'

  try {
    const exported = await exportCurrentProgress('pause')

    status.textContent = exported.copied
      ? `Pausiert. ${exported.count} bereits vollständig gelesene Bestellung(en) wurden sofort ausgewertet und in die Zwischenablage kopiert.\nDu kannst den Teil-Batch jetzt in CardCargo importieren oder später „Fortsetzen“ klicken.`
      : 'Pausiert. Es wurde bisher noch keine Bestelldetailseite vollständig gelesen; deshalb gibt es noch keinen Teil-Batch zum Export.'
  } catch (error) {
    status.textContent =
      error instanceof Error
        ? `Pausiert, aber Zwischenexport fehlgeschlagen: ${error.message}`
        : 'Pausiert, aber Zwischenexport fehlgeschlagen.'
  }
})

stopButton.addEventListener('click', async () => {
  if (!running) return

  stopRequested = true
  paused = false
  pauseButton.textContent = 'Pausieren'

  try {
    const exported = await exportCurrentProgress('stop')

    status.textContent = exported.copied
      ? `Beenden angefordert. ${exported.count} bereits vollständig gelesene Bestellung(en) wurden sofort ausgewertet und in die Zwischenablage kopiert.\nDer aktuell laufende kleine Schritt wird noch sauber beendet; danach stoppt der Sync.`
      : 'Beenden angefordert. Es wurde bisher noch keine Bestelldetailseite vollständig gelesen. Der aktuelle kleine Schritt wird beendet; danach stoppt der Sync.'
  } catch (error) {
    status.textContent =
      error instanceof Error
        ? `Beenden angefordert, aber Zwischenexport fehlgeschlagen: ${error.message}`
        : 'Beenden angefordert, aber Zwischenexport fehlgeschlagen.'
  }
})


exportPartialButton.addEventListener('click', async () => {
  if (!lastExportPayload) return

  try {
    await navigator.clipboard.writeText(
      JSON.stringify(lastExportPayload, null, 2),
    )

    status.textContent =
      `${lastExportPayload.orders.length} Bestellung(en) wurden erneut als Teil-Batch in die Zwischenablage kopiert.`
  } catch (error) {
    status.textContent =
      error instanceof Error
        ? error.message
        : 'Teil-Batch konnte nicht erneut kopiert werden.'
  }
})


last7Button.addEventListener('click', async () => {
  const range = defaultLast7Days()

  dateFromInput.value = range.from
  dateToInput.value = range.to
  await saveDateRange(range)

  status.textContent =
    `Zeitraum auf die letzten 7 Tage gesetzt: ${range.from} bis ${range.to}.`
})

dateFromInput.addEventListener('change', async () => {
  try {
    const range = validateDateRange()
    await saveDateRange(range)
  } catch (error) {
    status.textContent =
      error instanceof Error ? error.message : 'Ungültiger Zeitraum.'
  }
})

dateToInput.addEventListener('change', async () => {
  try {
    const range = validateDateRange()
    await saveDateRange(range)
  } catch (error) {
    status.textContent =
      error instanceof Error ? error.message : 'Ungültiger Zeitraum.'
  }
})

resetButton.addEventListener('click', async () => {
  if (
    !confirm(
      'Lokalen Sync- und Netzwerk-Capture-Stand wirklich zurücksetzen?',
    )
  ) {
    return
  }

  await chrome.storage.local.remove([SYNC_KEY, CAPTURE_KEY, PARTIAL_EXPORT_KEY])
  status.textContent = 'Lokaler Sync-/Capture-Stand wurde zurückgesetzt.'
  renderSummary([])
})


void restorePersistentExport().then((payload) => {
  if (!payload) return

  status.textContent =
    `${payload.orders.length} bereits gelesene Bestellung(en) aus dem letzten Zwischenstand sind weiterhin exportierbar.`

  const stats = summarizeOrders(payload.orders)
  renderSummary([
    ['Gespeicherter Zwischenstand', payload.orders.length],
    ['Warenwert erkannt', stats.priceCount],
    ['Kaufdatum erkannt', stats.dateCount],
    ['Tracking erkannt', stats.trackingCount],
  ])
})

void initializeDateRange()
